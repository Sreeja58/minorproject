from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
from flask_mysqldb import MySQL
import os
import firebase_admin
from firebase_admin import credentials, storage


app = Flask(__name__)
app.secret_key = 'your_secret_key'

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'mysql'
app.config['MYSQL_DB'] = 'your_mysql_database'
mysql = MySQL(app)


# Routes
@app.route('/')
def home():
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username == 'Mukul' and password == 'Mukul':
            return redirect(url_for('upload'))
        else:
            flash('Invalid username or password', 'error')

    return render_template('login.html')


@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        files = request.files.getlist('files')

        for file in files:
            # Save the file to a desired location
            # file.save('path_to_save_files/' + file.filename)
            file.save('D:/CTG files/' + file.filename)

        flash('Files uploaded successfully', 'success')

    return render_template('upload.html')


@app.route('/download')
def download():
    uploads_dir = 'D:/CTG files'
    files = os.listdir(uploads_dir)
    return render_template('download.html', files=files)
@app.route('/download/<filename>')
def download_file(filename):
    downloads_dir = 'D:/Downloaded_CTG_files'
    return send_from_directory(downloads_dir, filename, as_attachment=True)
# @app.route('/style')
# def send_css():
#     return send_from_directory('style','style.css')

if __name__ == '__main__':
    app.run(debug=True)
