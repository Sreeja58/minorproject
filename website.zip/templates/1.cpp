#include <iostream>
using namespace std;
void main(){
    int a[3] = {1,2,3}
    int *p = a;
    cout<<p<<a;
return 0;}