const uploadForm = document.getElementById('upload-form');
const fileInput = document.getElementById('file-input');
const downloadLinks = document.getElementById('download-links');

uploadForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(message => {
        alert(message);
        fileInput.value = '';
        fetchDownloadLinks();
    })
    .catch(error => console.error(error));
});

function fetchDownloadLinks() {
    fetch('/list')
    .then(response => response.json())
    .then(data => {
        downloadLinks.innerHTML = '';
        data.files.forEach(filename => {
            const link = document.createElement('a');
            link.href = `/download/${filename}`;
            link.textContent = filename;
            link.download = filename; // Set the "download" attribute to specify the filename
            downloadLinks.appendChild(link);
            downloadLinks.appendChild(document.createElement('br'));
        });
    })
    .catch(error => console.error(error));
}

fetchDownloadLinks();
